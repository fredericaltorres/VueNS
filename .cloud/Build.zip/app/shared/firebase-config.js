module.exports = {
   // persist: false,
    //firebaseBucket: "gs://car-rental-b26b7.appspot.com/",
    persist: false
   


};
