

# Information about publishing a NativeScript Vue app to my iPhone

- Reference Video: https://www.youtube.com/watch?v=5gKuR2UCOnM

## App Id:
- Name: VueNS App

## BundleId / Application Identifier
- Value: com.frederictorres.VueNSApp

## Prefix
- Value: J5BZJ67Z3S

## Register Device

# Certificate
- File: CSR Development.csr
- File: ios_development.cer
- File: Development Certificate P12.p12

## Provisionning Profile

- File: VueNS_App__Development_Profile.mobileprovision